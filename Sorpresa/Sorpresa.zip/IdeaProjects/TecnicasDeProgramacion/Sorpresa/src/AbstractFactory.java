public abstract class AbstractFactory {
    abstract public Dialogo generaDialogo ();
}
