public class DialogoWindows implements Dialogo{

    public int conversar(){
        System.out.println("Hola, soy un dialogo de Windows");
        return 0;
    }
}
