import java.util.Scanner;

public class Prueba {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        String a = sc.next();
        System.out.println("hola");
        String b = sc.nextLine();

        System.out.println(a);
        System.out.println(b + "<----");



    }
}
