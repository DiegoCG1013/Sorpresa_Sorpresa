public interface Impresion {

    public void imprimirTodo();
}
